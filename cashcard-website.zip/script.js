function calculate() {
  const amount = parseFloat(document.getElementById("amount").value);
  if (isNaN(amount)) {
    document.getElementById("result").innerText = "กรุณากรอกจำนวนเงินที่ถูกต้อง";
    return;
  }

  const fee = amount * 0.035;
  const total = amount + fee;

  document.getElementById("result").innerText = 
    `รวมค่าธรรมเนียมแล้ว: ${total.toFixed(2)} บาท`;
}